#include <iostream>
using namespace std;
int main()
{
	int y;
	cin>>y;
	if (y>=1 && y<=100)

{
	for (int i=y;i>=1;i--)
	{
	if (i%7==0)cout<<i<<endl;
}
return 0;
}
}
